"""WIRE-FL: byte-capped, screened and audited federated learning for wearable sensing."""

from .config import PRESETS, Config, __version__, data_config, get_config
from .federated import LR_SEARCH, WIRE_FL, Protocol, Scenario, run_federated
from .inference import WIREPredictor
from .pipeline import run_fold, run_loso

__all__ = [
    "Config",
    "PRESETS",
    "get_config",
    "data_config",
    "Protocol",
    "Scenario",
    "WIRE_FL",
    "LR_SEARCH",
    "run_federated",
    "run_fold",
    "run_loso",
    "WIREPredictor",
    "__version__",
]
