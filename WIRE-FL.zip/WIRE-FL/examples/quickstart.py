"""Train WIRE-FL on the built-in synthetic fixture, then score held-out rows with the saved artifact.

Runs in seconds. Replace ``synthetic=True`` and the data configuration with your dataset folders to use
real data (see README).
"""

import tempfile

from wire_fl import WIREPredictor, get_config, run_fold, Scenario
from wire_fl.config import data_config
from wire_fl.features import load_data
from wire_fl.preprocessing import make_splits, role_frame

cfg = get_config("smoke")
df, provenance = load_data(data_config(), synthetic=True)
cohort = df[df.dataset == "SLEEP"].copy()
split = make_splits(cohort, cfg)[0]  # first held-out subject

with tempfile.TemporaryDirectory() as out:
    result = run_fold(cohort, split, cfg, Scenario(), seed=13, root=out, code_hash="example", synthetic=True)
    print(f"held-out {split['held']}: macro-F1 = {result['metrics']['macro_f1']:.3f}")
    print(f"uplink bytes over {result['system']['completed_rounds']} rounds: {result['system']['uplink_bytes']}")

    predictor = WIREPredictor.load(result["run_dir"] + "/artifact.pkl")
    test = role_frame(cohort, split, "test")
    print(predictor.predict_proba(test)[:5], predictor.predict(test)[:5])
